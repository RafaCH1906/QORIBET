package org.ide.pc1.dto.RequestDTO;

import jakarta.validation.constraints.Email;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserDTO {
    private String username;

    @Email(message = "El formato de email es incorrecto")
    private String email;

    private String password;


}
