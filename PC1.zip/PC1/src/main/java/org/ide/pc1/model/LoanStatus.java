package org.ide.pc1.model;

public enum LoanStatus {
    ACTIVE,
    RETURNED,
    OVERDUE
}
