package org.ide.pc1.dto.RequestDTO;

import jakarta.validation.constraints.Min;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BookDTO {
    private Long id;

    private String title;

    private String author;

    @Min(0)
    private Integer totalCopies;

    @Min(0)
    private Integer availableCopies;


}
