package org.ide.pc1.service;

import lombok.NoArgsConstructor;
import org.ide.pc1.repository.BookRepository;
import org.springframework.stereotype.Service;

@Service
@NoArgsConstructor
public class BookService {

    private final BookRepository bookRepository;
    public BookService(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }
}
