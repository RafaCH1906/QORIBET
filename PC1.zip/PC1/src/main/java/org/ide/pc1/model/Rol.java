package org.ide.pc1.model;

public enum Rol {
    ROLE_READER
}
