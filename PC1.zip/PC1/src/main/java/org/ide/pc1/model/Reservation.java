package org.ide.pc1.model;

import jakarta.persistence.*;
import lombok.*;

import java.time.ZonedDateTime;

@Entity
@Table(name = "reservations")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Reservation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Relación con Book
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "book_id", nullable = false)
    private Book book;

    // Relación con User
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    private ZonedDateTime reservedAt;
    private ZonedDateTime expiredAt;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private ReservationStatus reservationStatus;

    @PrePersist
    public void prePersist() {
        if (reservedAt == null) {
            reservedAt = ZonedDateTime.now();
        }
        if (expiredAt == null) {
            expiredAt = reservedAt.plusHours(48);
        }
        if (reservationStatus == null) {
            reservationStatus = ReservationStatus.PENDING;
        }
    }
}
