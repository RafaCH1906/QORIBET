package org.ide.pc1.service;

public class LoanService {
}
