package org.ide.pc1.dto.RequestDTO;

import org.springframework.data.domain.Page;

import java.util.List;

public class PagedResponseDTO<T> {
    private List<T> content;
    private int page;
    private int size;
    private long totalElements;

    public PagedResponseDTO(Page<T> pageresult) {
        this.content = pageresult.getContent();
        this.totalElements = pageresult.getTotalElements();
        this.page = pageresult.getNumber();
        this.size = pageresult.getSize();
    }
}
