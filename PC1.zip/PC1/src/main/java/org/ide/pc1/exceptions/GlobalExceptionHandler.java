package org.ide.pc1.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

@RestControllerAdvice
public class GlobalExceptionHandler  {

    @ExceptionHandler(UserNotfoundException.class)
    public ResponseEntity<Map<String, Object>> handleUserNotFound(UserNotfoundException ex) {
        return buildErrorResponse(HttpStatus.NOT_FOUND, "Usuario no encontrado", ex.getMessage());
    }

    // Manejador para excepción de usuario ya existe
    @ExceptionHandler(UserAlreadyExitsException.class)
    public ResponseEntity<Map<String, Object>> handleUserAlreadyExists(UserAlreadyExitsException ex) {
        return buildErrorResponse(HttpStatus.CONFLICT, "Usuario ya existe", ex.getMessage());
    }

    @ExceptionHandler(BookNotFoundException.class)
    public ResponseEntity<Map<String, Object>> handleBookNotFound(BookNotFoundException ex) {
        return buildErrorResponse(HttpStatus.NOT_FOUND, "Book no encontrado", ex.getMessage());
    }

    @ExceptionHandler(NoCopiesAvailableException.class)
    public ResponseEntity<Map<String, Object>> handleNoCopiesAvailable(NoCopiesAvailableException ex) {
        return buildErrorResponse(HttpStatus.CONFLICT, "No puede hacer copiendo", ex.getMessage());
    }

    @ExceptionHandler(LoanNotFoundException.class)
    public ResponseEntity<Map<String, Object>> handleLoanNotFound(LoanNotFoundException ex) {
        return buildErrorResponse(HttpStatus.NOT_FOUND, "Loan no encontrado", ex.getMessage());
    }


    @ExceptionHandler(OverduelLoanException.class)
    public ResponseEntity<Map<String, Object>> handleOverduelLoan(OverduelLoanException ex) {
        return buildErrorResponse(HttpStatus.BAD_REQUEST, "Loan ya existe", ex.getMessage());
    }

    @ExceptionHandler(UnauthorizedException.class)
    public ResponseEntity<Map<String, Object>> handleUnauthorized(UnauthorizedException ex) {
        return buildErrorResponse(HttpStatus.UNAUTHORIZED, "Usuario no encontrado", ex.getMessage());
    }



    // Manejador para excepciones de validación de argumentos
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<Map<String, Object>> handleValidationExceptions(MethodArgumentNotValidException ex) { // Maneja MethodArgumentNotValidException
        Map<String, String> errors = new HashMap<>(); // Mapa para almacenar errores de validación
        ex.getBindingResult().getAllErrors().forEach(error -> { // Itera sobre todos los errores de validación
            String fieldName = ((FieldError) error).getField(); // Obtiene el nombre del campo con error
            String errorMessage = error.getDefaultMessage(); // Obtiene el mensaje de error
            errors.put(fieldName, errorMessage); // Agrega el error al mapa
        });

        // Construye la respuesta de error con detalles de validación
        Map<String, Object> response = new HashMap<>(); // Mapa para la respuesta
        response.put("timestamp", LocalDateTime.now()); // Marca de tiempo del error
        response.put("status", HttpStatus.BAD_REQUEST.value()); // Código de estado 400
        response.put("error", "Error de validación"); // Tipo de error
        response.put("message", errors); // Mensajes de error de validación

        // Retorna la respuesta con estado 400 Bad Request
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response); // Responde con 400 y detalles de validación
    }

    // Manejador para excepciones genéricas
    @ExceptionHandler(Exception.class)
    public ResponseEntity<Map<String, Object>> handleGenericException(Exception ex) { // Maneja cualquier otra excepción no capturada
        return buildErrorResponse(HttpStatus.INTERNAL_SERVER_ERROR, "Error interno del servidor", ex.getMessage()); // Responde con 500 y mensaje de error
    }

    // Metodo auxiliar para construir respuestas de error consistentes
    private ResponseEntity<Map<String, Object>> buildErrorResponse(HttpStatus status, String error, String message) { // Construye una respuesta de error
        Map<String, Object> response = new HashMap<>(); // Mapa para la respuesta
        response.put("timestamp", LocalDateTime.now()); // Marca de tiempo del error
        response.put("status", status.value()); // Código de estado HTTP
        response.put("error", error); // Tipo de error
        response.put("message", message); // Mensaje de error detallado
        return ResponseEntity.status(status).body(response); // Retorna la respuesta con el estado y cuerpo especificados
    }
}
