package org.ide.pc1.model;

public enum ReservationStatus {
    PENDING,
    EXPIRED,
    CANCELLED
}
