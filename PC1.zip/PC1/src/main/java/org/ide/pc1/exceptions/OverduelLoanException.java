package org.ide.pc1.exceptions;

public class OverduelLoanException extends RuntimeException {
    public OverduelLoanException(String message) {
        super(message);
    }
}
