package org.ide.pc1.security;

import lombok.RequiredArgsConstructor;
import org.ide.pc1.exceptions.UserNotfoundException;
import org.ide.pc1.model.Book;
import org.ide.pc1.repository.BookRepository;
import org.ide.pc1.repository.UserRepository;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.Optional;
@Service
@RequiredArgsConstructor
public class UserDetailsServiceImpl implements UserDetailsService {

    private final UserRepository userRepository;
    private final BookRepository bookRepository;

    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        Optional<org.ide.pc1.model.User> User = userRepository.findByEmail(email);
        if (User.isPresent()) {
            org.ide.pc1.model.User e = User.get();
            return new User(
                    e.getEmail(),
                    e.getPassword(),
                    Collections.singleton(new SimpleGrantedAuthority(e.getRol().name()))
            );
        }

        throw new UserNotfoundException("Usuario no encontrado: " + email);
    }
}