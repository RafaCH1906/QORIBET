package org.ide.pc1.exceptions;

public class UserAlreadyExitsException extends RuntimeException {
    public UserAlreadyExitsException(String message) {
        super(message);
    }
}
